from typing import TypeAlias, TypeVar, Union, overload

import drjit as dr
import drjit


ArrayT = TypeVar("ArrayT", bound=drjit.ArrayBase)

Shape: TypeAlias = Union[int, tuple[int, ...]]

ArrayOrInt: TypeAlias = Union[int, drjit.ArrayBase]

ArrayOrFloat: TypeAlias = Union[float, drjit.ArrayBase]

class Generator:
    def random(self, dtype: type[ArrayT], shape: Union[int, tuple[int, ...]]) -> ArrayT:
        """
        Return a Dr.Jit array or tensor containing uniformly distributed
        pseudorandom variates.

        This function supports floating point arrays/tensors of various
        configurations and precisions, e.g.:

        .. code-block:: python

           from drjit.cuda import Float, TensorXf, Array3f, Matrix4f

           # Example usage
           rng = dr.rng(seed=0)
           rand_array = rng.random(Float, 128)
           rand_tensor = rng.random(TensorXf16, shape=(128, 128))
           rand_vec = rng.random(Array3f, (3, 128))
           rand_mat = rng.random(Matrix4f64, (4, 4, 128))

        The output is uniformly distributed the half-open interval :math:`[0, 1)`.
        Integer arrays are not supported.

        Args:
            source (type[ArrayT]): A Dr.Jit tensor or array type.

            shape (int | tuple[int, ...]): The target shape

        Returns:
            ArrayT: The generated array of random variates.
        """

    def uniform(self, dtype: type[ArrayT], shape: Union[int, tuple[int, ...]], low: Union[float, drjit.ArrayBase] = 0.0, high: Union[float, drjit.ArrayBase] = 1.0):
        """
        Return a Dr.Jit array or tensor containing uniformly distributed
        pseudorandom variates.

        This function resembles :py:func:`random()` but additionally ensures
        that variates are distributed on the half-open interval
        :math:`[	exttt{low}, 	exttt{high})`.

        Args:
            source (type[ArrayT]): A Dr.Jit tensor or array type.

            shape (int | tuple[int, ...]): The target shape

            low (float | drjit.ArrayBase): The low value of the desired interval

            high (float | drjit.ArrayBase): The high value of the desired interval

        Returns:
            ArrayT: The generated array of random variates.
        """

    def integers(self, dtype: type[ArrayT], shape: Union[int, tuple[int, ...]], low: Union[int, drjit.ArrayBase] = 0, high: Union[int, drjit.ArrayBase, None] = None, endpoint: bool = False) -> ArrayT:
        """
        Return a Dr.Jit array or tensor containing uniformly distributed
        pseudorandom 32-bit integers.

        If ``high`` is ``None``, integers are drawn from ``[0, low)``.
        Otherwise, integers are drawn from ``[low, high)``, or ``[low, high]``
        if ``endpoint=True``.

        Args:
            dtype (type[ArrayT]): A Dr.Jit 32-bit integer array type
                (``Int32`` or ``UInt32``).

            shape (int | tuple[int, ...]): The target shape

            low (int | drjit.ArrayBase): Lowest integer to be drawn (inclusive).
                If ``high`` is ``None``, this parameter specifies the exclusive
                upper bound, and 0 becomes the lower bound.

            high (int | drjit.ArrayBase | None): If provided, one above the
                largest integer to be drawn. If ``endpoint=True``, this is the
                largest integer to be drawn (inclusive).

            endpoint (bool): If ``True``, ``high`` is inclusive. Default: ``False``.

        Returns:
            ArrayT: The generated array of random integers.
        """

    def normal(self, dtype: type[ArrayT], shape: Union[int, tuple[int, ...]], loc: Union[float, drjit.ArrayBase] = 0.0, scale: Union[float, drjit.ArrayBase] = 1.0) -> ArrayT:
        """
        Return a Dr.Jit array or tensor containing pseudorandom variates
        following a standard normal distribution

        This function supports arrays/tensors of various configurations and
        precisions--see the similar :py:func:`drjit.random()` for examples on
        how to call this function.

        Args:
            source (type[ArrayT]): A Dr.Jit tensor or array type.

            shape (int | tuple[int, ...]): The target shape

            loc (float | drjit.ArrayBase): The mean of the normal distribution (``0.0`` by default)

            scale (float | drjit.ArrayBase): The standard deviation of the normal distribution (``1.0`` by default)

        Returns:
            ArrayT: The generated array of random variates.
        """

    @overload
    def permutation(self, dtype: type[ArrayT], n: int, /) -> ArrayT:
        """
        Generate a random permutation of elements.

        If ``x`` is a type and ``n`` is an integer, return a random
        permutation of ``dr.arange(dtype, n)``.

        If ``x`` is a 1D Dr.Jit array, return a new array containing the
        same elements in a uniformly random order.

        If ``x`` is a tensor, shuffle along the given ``axis`` (default
        ``0``): each slice along that axis is kept intact, but their order
        is randomized.

        The implementation generates uniform random float keys and calls
        :py:func:`drjit.argsort` to obtain a permutation using an
        efficient parallel radix sort on both CPU and GPU backends.

        Overloaded signatures:

        .. py:function:: permutation(dtype, n, /)
           :noindex:

           Return a random permutation of indices ``[0, n)``.

           :param type dtype: A Dr.Jit array type (e.g., ``dr.cuda.UInt32``)
               that selects the backend. The return type is the corresponding
               ``UInt32`` type for that backend.
           :param int n: Length of the permutation (must be non-negative).

        .. py:function:: permutation(x, /, axis=0)
           :noindex:

           Return a shuffled copy of an array or tensor.

           :param drjit.ArrayBase x: Input array or tensor to shuffle.
           :param int axis: Axis along which to shuffle (tensors only,
               default: ``0``). Negative indices are supported.
        """

    @overload
    def permutation(self, x: ArrayT, /, axis: int = 0) -> ArrayT: ...

    def clone(self) -> Generator: ...

class Philox4x32Generator(Generator):
    """
    Implementation of the :py:class:`Generator` interface based on the Philox4x32 RNG.
    """

    DRJIT_STRUCT: dict = ...

    def __init__(self, seed: Union[int, drjit.ArrayBase] = 0, counter: Union[int, drjit.ArrayBase] = 0, symbolic: bool = False): ...

    def clone(self) -> Generator: ...

    def random(self, dtype: type[ArrayT], shape: Union[int, tuple[int, ...]]) -> ArrayT: ...

    def integers(self, dtype: type[ArrayT], shape: Union[int, tuple[int, ...]], low: Union[int, drjit.ArrayBase] = 0, high: Union[int, drjit.ArrayBase, None] = None, endpoint: bool = False) -> ArrayT: ...

    def normal(self, dtype: type[ArrayT], shape: Union[int, tuple[int, ...]], loc: Union[float, drjit.ArrayBase] = 0.0, scale: Union[float, drjit.ArrayBase] = 1.0) -> ArrayT: ...

    def __repr__(self) -> str: ...
