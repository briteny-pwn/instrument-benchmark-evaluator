#!/usr/bin/env python
#
# petname
#
# Copyright 2014 Dustin Kirkland <dustin.kirkland@gmail.com>
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import argparse
import petname
import sys

def main() -> None:
	parser = argparse.ArgumentParser(description='Generate human readable random names')
	parser.add_argument('-w', '--words', help='Number of words in name, default=2', default=2)
	parser.add_argument('-l', '--letters', help='Maximum number of letters per word, default=6', default=6)
	parser.add_argument('-s', '--separator', help='Separator between words, default="-"', default="-")
	parser.options = parser.parse_args()

	# Validate and convert arguments
	try:
		words = int(parser.options.words)
		letters = int(parser.options.letters)
	except ValueError:
		sys.stderr.write("Error: --words and --letters must be valid integers\n")
		sys.exit(1)

	# Validate separator length (prevent memory DoS)
	if len(parser.options.separator) > 100:
		sys.stderr.write("Error: --separator must be 100 characters or less\n")
		sys.exit(1)

	sys.stdout.write(petname.Generate(words, parser.options.separator, letters) + "\n")

if __name__ == "__main__":
	main()
